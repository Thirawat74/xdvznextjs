export { QRScanner } from './QRScanner';
