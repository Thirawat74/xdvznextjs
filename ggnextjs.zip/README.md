เอา API KEY ได้จาก
https://ads4u.co
https://www.middle-pay.com